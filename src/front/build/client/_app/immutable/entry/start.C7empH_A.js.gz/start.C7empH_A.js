import{l as o,a as r}from"../chunks/zTMk2nm5.js";export{o as load_css,r as start};
