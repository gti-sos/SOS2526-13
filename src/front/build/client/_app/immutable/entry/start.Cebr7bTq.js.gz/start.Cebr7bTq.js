import{l as o,a as r}from"../chunks/X7_LtauD.js";export{o as load_css,r as start};
