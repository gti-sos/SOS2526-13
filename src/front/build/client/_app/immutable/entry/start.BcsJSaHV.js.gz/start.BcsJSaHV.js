import{l as o,a as r}from"../chunks/CVuEim6V.js";export{o as load_css,r as start};
